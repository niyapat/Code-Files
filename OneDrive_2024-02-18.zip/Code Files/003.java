class Average {
    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 6;
        int num3 = 9;
        double average = (num1 + num2 + num3) / 3;
        System.out.println("The average of " + num1 + ", " + num2 + ", "+ num3 + " is "+ average);
    }
}