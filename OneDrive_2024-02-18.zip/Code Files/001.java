// Area of a circle without User Input

class CircleWithoutInput {
public static void main(String[] args) {
    double radius = 5.5;
    double area = (22/7)*radius*radius;
    System.out.println("Circle with the radius is: " + area);
}
}