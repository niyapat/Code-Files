// class relation {
//     public static void main(String[] args) {
//        double radius = 5;
//        System.out.println(radius<0);
//     }
// }

// **************************** 
// Game in Java (Addition Quiz) 
// import java.util.Scanner;
// class AdditionQuiz{
//     public static void main(String[] args) {
//         // Input from the user 
//         Scanner input = new Scanner(System.in);
//         // Two random number generation 
//         int num1 = (int)(System.currentTimeMillis() % 100);
//         int num2 = (int)(System.currentTimeMillis() / 7 % 100);

//         System.out.println("What is " + num1 + "+" +num2 + "=" + "?");
//         int answer = input.nextInt();
//         System.out.println(num1 + "+" + num2 + "=" + answer + " is "+ (num1+num2 == answer));
//         input.close();
//     }
// }

// ************************** 

// import java.util.Scanner;

// class SimpleIfElse{
//     public static void main(String[] args) {
//         Scanner input = new Scanner(System.in);
//         System.out.println("Enter an Integer");
//         int x = input.nextInt();
//         if (x % 2 == 0) {
//             System.out.println(x + " is " + "Even Number");
//         }else{
//             System.out.println(x + " is " + "Odd Number");
//         }
//         input.close();
//     }
// }