// STRINGS 

// class First {
//     public static void main(String[] args) {
//         String text = "Hello from Java";
//         System.out.println("This is initialization step: " + text);
// }
// }

// ******************** 

// String Concatenation 

// class StrCon {
//     public static void main(String[] args) {
//         String firstName = "John";
//         String lastName = "Doe";
        // String fullName = firstName + " " + lastName;
//         System.out.println("The Full name of the user is: " + fullName);
//     }
// }

// ************** 

// class StrCon {
//     public static void main(String[] args) {
//         String firstName = "John";
//         String lastName = "Doe";
//         String fullName = firstName.concat(" ").concat(lastName);
//         System.out.println("The Full name of the user is: " + fullName);
//     }
// }

// ****************** 

// String length 
// class Length {
//     public static void main(String[] args) {
//         String str1 = "Hello World!";
//         int len = str1.length();
//         System.out.println("Length of string is : "+ len);
//     }
// }

// ************************* 

// String Comparison 
// class Compare{
//     public static void main(String[] args) {
//         String s1 = "yes";
//         String s2 = "YeS";
//         System.out.println("Equals: " + s1.equals(s2)); 
//         System.out.println("Ignore The Cases: " + s1.equalsIgnoreCase(s2));  
//     }
// }

// ***************** 

// class Converse {
//     public static void main(String[] args) {
//         String str = "Hello From JAVA";
//         System.out.println("Upper Case: " + str.toUpperCase());
//         System.out.println("Lower Case: " + str.toLowerCase());
//     }
// }