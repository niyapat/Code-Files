// Logical Operator 

// 1- Generate a lottery of two-digit and it should be enter by user 

// 2- if user input matches the lottery number with exact order then award is $10,000 ex. 51  & 51 (user input) $10,000

// 3- if user input matches the digits but not in order then price will be $3,000 ex.  (25) or (52) user input $3,000

// 4- if any one digit is matches with the lottery then the award is $1,000 ex. 82 and 87 user input $1,000 

import java.util.Scanner;
class Lottery {
    public static void main(String[] args) {
        int lottery = (int)(Math.random()*100);

        // Prompt for user input 
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your two digit number: ");
        int guess = input.nextInt();

        // Get digits from lottery 
        int lotteryDigit1 = lottery / 10;
        int lotteryDigit2 = lottery % 10;

        //Get digits from the guess by the user 
        int guessDigit1 = guess / 10;
        int guessDigit2 = guess % 10;

        System.out.println("The lottery number is:" + lottery);

        // Checking the guess 
        if (guess == lottery) {
            System.out.println("EXACT MATCH: YOU WIN $10,000" );
        }
        else if (guessDigit2 == lotteryDigit1 && guessDigit1 == lotteryDigit2){
            System.out.println("ONE MATCH: YOU WIN $3,000");
        }
        else if (guessDigit1 == lotteryDigit1 
                || guessDigit1 == lotteryDigit2 
                || guessDigit2 == lotteryDigit1 
                || guessDigit2 == lotteryDigit2){
             System.out.println("MATCH ONE DIGIT: YOU WIN $1,000");
        }
        else {
            System.out.println("SORRY, NO MATCH.");
        }

        input.close();
    }
}